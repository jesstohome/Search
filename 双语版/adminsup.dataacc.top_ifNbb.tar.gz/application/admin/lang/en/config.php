<?php

return [
    'name'  => 'Variable Name',
'intro' => 'Description',
'group' => 'Group',
'type'  => 'Type',
'value' => 'Variable Value'

];
