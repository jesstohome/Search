<?php

return [
        'Url'                                         => 'URL',
    'Userame'                                     => 'Username',
    'Createtime'                                  => 'Operation Time',
    'Click to edit'                               => 'Click to edit',
    'Admin log'                                   => 'Operation Log',
    'Leave password blank if dont want to change' => 'Leave blank to keep current password',
    'Please input correct email'                  => 'Please enter a valid email address',
    'Please input correct password'               => 'Password length incorrect',
    'Email already exists'                        => 'Email already exists',
];
