<?php

return [
        'Group'                                     => 'Group',
    'Loginfailure'                              => 'Login failures',
    'Login time'                                => 'Last login',
    'The parent group exceeds permission limit' => 'Parent group exceeds permission limits',
    'Please input correct username'             => 'Username must be 3-12 characters (letters, numbers, underscore)',
    'Please input correct password'             => 'Password must be 6-16 characters, no spaces allowed',
];
