<?php

return [
        'The parent group can not be its own child'                            => 'Parent group cannot be its own child',
    'The parent group can not found'                                       => 'Parent group not found',
    'Group not found'                                                      => 'Group not found',
    'Can not change the parent to child'                                   => 'Cannot set parent to child group',
    'Can not change the parent to self'                                    => 'Cannot set parent to self',
    'You can not delete group that contain child group and administrators' => 'Cannot delete group containing child groups and administrators',
    'The parent group exceeds permission limit'                            => 'Parent group exceeds permission limits',
    'The parent group can not be its own child or itself'                  => 'Parent group cannot be its own child or itself',
];
