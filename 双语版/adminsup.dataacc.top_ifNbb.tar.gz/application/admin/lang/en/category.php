<?php

return [
    'Id'                                 => 'ID',
'Pid'                                => 'Parent ID',
'Type'                               => 'Type',
'All'                                => 'All',
'Image'                              => 'Image',
'Keywords'                           => 'Keywords',
'Description'                        => 'Description',
'Diyname'                            => 'Custom Name',
'Createtime'                         => 'Creation Time',
'Updatetime'                         => 'Update Time',
'Weigh'                              => 'Weight',
'Category warmtips'                  => 'Tips: For category type, please go to <b>General Management</b>-><b>System Configuration</b>-><b>Dictionary Configuration</b> for management',
'Can not change the parent to child or itself' => 'The parent group cannot be its child group or itself',
'Status'                             => 'Status'

];
