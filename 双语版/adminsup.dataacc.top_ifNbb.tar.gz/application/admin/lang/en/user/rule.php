<?php

return [
        'Pid'        => 'Parent ID',
    'Name'       => 'Rule',
    'Title'      => 'Title',
    'Remark'     => 'Remark',
    'Ismenu'     => 'Is Menu',
    'Createtime' => 'Create Time',
    'Updatetime' => 'Update Time',
    'Menu tips'  => 'Rule can be arbitrary, must be unique, used for hierarchy display only, no need to match controller and method',
    'Node tips'  => 'Module/Controller/Method',
    'Weigh'      => 'Weight',
    'Status'     => 'Status',
];
