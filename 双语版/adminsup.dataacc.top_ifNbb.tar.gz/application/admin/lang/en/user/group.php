<?php

return [
        'Name'       => 'Group Name',
    'Rules'      => 'Permission Nodes',
    'Createtime' => 'Create Time',
    'Updatetime' => 'Update Time',
    'Status'     => 'Status',
];
